# pypip

[![PyPI - Version](https://img.shields.io/pypi/v/pypip.svg)](https://pypi.org/project/pypip)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pypip.svg)](https://pypi.org/project/pypip)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install pypip
```

## License

`pypip` is distributed under the terms of the [apache-2.0](https://spdx.org/licenses/apache-2.0.html) license.
